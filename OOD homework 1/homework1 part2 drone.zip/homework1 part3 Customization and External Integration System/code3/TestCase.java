import java.util.List;

public class TestCase {
    public static void main(String[] args) {
        CSVDeviceAdapter deviceAdapter = new CSVDeviceAdapter();
        deviceAdapter.readDevicesFromCSV("code3/Sample.csv");

        List<Phone> phones = deviceAdapter.getPhones();
        List<Laptop> laptops = deviceAdapter.getLaptops();

        System.out.println("Devices:");
        if (phones.isEmpty() && laptops.isEmpty()) {
            System.out.println("No devices found.");
        } else {
            for (int i = 0; i < phones.size(); i++) {
                System.out.println(phones.get(i));
            }
            for (int i = 0; i < laptops.size(); i++) {
                System.out.println(laptops.get(i));
            }
        }
    }
}